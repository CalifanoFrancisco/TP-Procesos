export interface PiezasLinker {
    id_pieza: Number,
    id_componente: Number
};