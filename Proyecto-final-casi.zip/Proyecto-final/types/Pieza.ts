export interface Pieza {
    id: Number,
    material: String,
    peso: Number,
};