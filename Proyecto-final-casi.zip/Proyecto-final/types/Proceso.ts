export interface Proceso {
    id: Number,
    id_pieza_salida: Number,
    tipo: String
};