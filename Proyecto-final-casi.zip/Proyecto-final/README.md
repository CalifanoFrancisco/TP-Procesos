@Initialization commands

npm init
tsc --init
npm install

@ Routes
GET ----> find() ---> find element/s                                 
POST ---> create() -> create new element                             
PATCH --> update() -> modify element                                 
DELETE -> drop() ---> delete element                                 


