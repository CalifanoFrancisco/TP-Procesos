//get all order objects
GET orders/

//create a new order
POST orders/

//get order by order ID
GET orders/:id

//update the order given by order ID
PUT orders/:id